const ytdl = require('ytdl-core');
const ytSearch = require('yt-search');

//const prefix = '!';

module.exports = function music(message) {
    
};